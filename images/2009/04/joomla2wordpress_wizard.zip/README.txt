Step by Step Instruction:

1. Unzip Joomla2WordPress.zip
2. Edit config.php and enter all missing values
3. Upload files to /export on your server
4. Add Categories in wordpress which you want to import into
5. Open www.yoursite.com/export/index.php on a browser
6. Select either a Joomla Section, Category or Links Category
7. Select a Wordpress Category to import into
8. Repeat Steps 5-7 till all of your articles have been imported
9. Enjoy and Spread the word!

Notes: 

- this application is created for a wordpress installation not in the root but in /root/wordpress on your server. If your wordpress installation is in the root or in another directory (eg: /root/blog, /root/posts) you have to adjust the following lines to this : 
	Line 11: if (!file_exists('../wordpress/wp-config.php')) 
	Line 17: require_once('../wordpress/wp-config.php');
	Line 21: $guessurl = str_replace('/wordpress/wp-admin/install.php?step=2', '', 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) );
	Line 312: 	require_once ("../wordpress/wp-includes/functions.php");
	Line 441: 	require_once ("../wordpress/wp-includes/functions.php");



-minor glitch: If you create a WP category which is empty (has no posts), the articles will import just fine, but the category may not appear in the categories widget until you open at least one post in that category in /wp-admin and just hit save. If anyone knows how to fix this minor bug email me holla@azeemkhan.info