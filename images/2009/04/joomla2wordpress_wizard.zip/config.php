<?php 

//********************************************************//
//               IMPORT SETTINGS
//********************************************************//

# CONFIG SECTION

  # Export Database Information - Your Joomla database that you want to export from.
  $dbh     = '';				//enter db name
  $dbuser = '';					//enter db username
  $dbpass = '';					//enter db password
  $dbhost = '';        // localhost is default
  $joomlatblprefix = ''; 	//jos_ is default

  # Import Database Information - Your WordPress database that you want to import into.
  $dbi     = '';				//enter db name
  $dbiuser = '';				//enter db username
  $dbipass = '';				//enter db password
  $dbihost = '';       // localhost is default
  $wptblprefix = ''; 		// wp_ is default
  $authorusername = ''; 	// admin is default

# END CONFIG SECTION  
?>  