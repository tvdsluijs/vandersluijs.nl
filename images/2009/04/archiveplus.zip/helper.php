<?php
/**
* @version		$Id: helper.php
* @copyright	Copyright (C) 2008 Theo van der Sluijs
* @license		http://creativecommons.org/licenses/by-nc-sa/3.0/nl/
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

class modArchivePlusHelper
{
	function getList(&$params)
	{
		//get database
		$db =& JFactory::getDBO();
		
    $content = $params->get('content');
    $ordering = $params->get('ordering');
    
    /*
    if($content == 1){ //archive only /  Maybe laterrrrrr
      $state = "state = -1 AND";
    }else{
      $state = "";
    }
    		<param name="content" type="list" default="1" label="Content" description="Select whether to use only archives or all content">
			<option value="1">Archive Only</option>
			<option value="0">All Content</option>
		</param>  
*/

    if($ordering == 1){//DESC
      $order = 'DESC';
    }else{
      $order = 'ASC';
    }

    $state = "state = -1 AND";
    
		$query = 'SELECT YEAR(created) AS created_year, MONTH( created ) AS created_month, count(*) as totals
					FROM #__content
					WHERE ( '.$state.' checked_out = 0 )
					GROUP BY created_year '.$order.', created_month '.$order.';';
					
		//$db->setQuery($query, 0, intval($params->get('count')));
		$db->setQuery($query);
		$rows = $db->loadObjectList();

		$menu = &JSite::getMenu();
		$item = $menu->getItems('link', 'index.php?option=com_content&view=archive', true);
		//$itemid = isset($item) ? '&Itemid='.$item->id : '';

		$i		= 0;
		$lists	= array();
		foreach ( $rows as $row ){
			$date =& JFactory::getDate($row->created_year.'-'.$row->created_month.'-01');

			//$created_month	= $date->toFormat("%m");
			//$month_name		= $date->toFormat("%B");
			//$created_year	= $date->toFormat("%Y");
			
			$created_month	= $row->created_month;
			$month_name		= $date->toFormat("%B");
			$created_year	= $row->created_year;

			$lists[$i]->yearlink	= JRoute::_('index.php?option=com_content&view=archive&year='.$created_year);
			$lists[$i]->monthlink	= JRoute::_('index.php?option=com_content&view=archive&year='.$created_year.'&month='.$created_month);
			$lists[$i]->cr_month	= $month_name;
			$lists[$i]->cr_year	= $created_year;
			$lists[$i]->totals	= $row->totals;
		
			$i++;
		}
		return $lists;
	}
}