<?php // no direct access
/**
* @version		$Id: default.php
* @copyright	Copyright (C) 2008 Theo van der Sluijs
* @license		http://creativecommons.org/licenses/by-nc-sa/3.0/nl/
*/
defined('_JEXEC') or die('Restricted access'); ?>
<?php 
$year = 0;
$listyear = "";
$styleyear = "";
foreach ($list as $item) :
	$nyear = $item->cr_year;
	if($nyear == $year){
	//do nothing;
	}else{
		$year = $nyear;
		$styleyear .= ".".$nyear."{list-style:none;}\n";
    	$styleyear .= "#L".$nyear."{list-style:none; margin-left:5px}\n";
    	$styleyear .= "#A".$nyear."{background:url(".$this->baseurl."/modules/mod_archiveplus/images/triangle_ltr.gif) no-repeat left center; width:10px;  cursor:pointer;  cursor:hand; float:left; }\n";
		if(!isset($listyear) || $listyear == ""){
			$listyear .= "'".$nyear."'";
		}else{
			$listyear .= ", '".$nyear."'";
		}
	}
endforeach; 
?>

<style>
<?php echo $styleyear;?>

#nav {
	margin: 0; padding: 0;
	width: 130px;
}

#nav p {
	letter-spacing: -1;
	padding: 2px 2px 2px 3px;
	margin: 0;

}

#nav p.extend {
	display: block;
}

#nav p a {
  padding-right:11px;
  color: #fff;  width: 128px;
}

#nav p a:hover {

}

#nav ul {
	display: none;
	list-style: none;
	margin: 0 0 10px 0; padding: 0;

}

#nav ul li {
	margin: 0 0 0 20px;
	padding: 1px;
	display: block;
}
#nav ul li a {
	text-decoration: none; 
	margin: 0 0 0 10px;  
}
#nav ul li a:hover {
	text-decoration: underline; 
}
#nav ul li ul {
	display: none;
	list-style: none;
	margin: 0; padding: 0;
}
#nav ul li ul li {
	border: none;
}

</style>

<script language="javascript">

var majors = new Array(<?php echo $listyear;?>);

function toggleList(a, b) {
	if (!document.getElementById) return true;
	
  if (b==1) for (var i=majors.length-1; i>=0; i--) if (majors[i] != a) document.getElementById(majors[i]).style.display='none';
  
  c=a;
  
	a=document.getElementById(c);
  b=document.getElementById('A'+c);
  
  if(a.style.display=='block'){
    a.style.display='none';
    b.style.background='url(\'<?php echo $this->baseurl ?>/modules/mod_archiveplus/images/triangle_ltr.gif\')';    
  }else{
    a.style.display='block';
    b.style.background='url(\'<?php echo $this->baseurl ?>/modules/mod_archiveplus/images/triangle_open.gif\')';
  }
  
	return false;
}
</script>

<div id="nav">
<?php 
$year = 0;
$lister = "";
$listheader = "";
$completelist = "";
$totals = 0;

foreach ($list as $item) :
	$nyear = $item->cr_year;
	
	if($year==0){
		$year = $nyear;
	}

	if($lister != "" && $nyear != $year){
      $yearlink = JRoute::_('index.php?option=com_content&view=archive&year='.$year);
			$listheader = "<p class=\"extend\"><div id=\"A".$year."\" onclick=\"javascript:toggleList('".$year."', 1)\">&nbsp;</div><div><a id=\"L".$year."\" href=\"".$yearlink."\">".$year."</a> (".$totals.")</div></p>";
			$listheader .= "<ul id=\"".$year."\" style=\"display:none\">";
			$completelist .= $listheader.$lister.'</ul>';
			$listheader = "";
			$lister = "";
			$totals = 0;
			$year = $nyear;
	}	
	
	$lister .= '<li><a href="'.$item->monthlink.'">'.$item->cr_month.'</a> ('.$item->totals.')</li>';
	$totals = $totals+$item->totals;
	
endforeach; 

$listheader = "<p class=\"extend\"><div id=\"A".$year."\" onclick=\"javascript:toggleList('".$year."', 1)\">&nbsp;</div><div><a id=\"L".$year."\" href=\"".$item->yearlink."\">".$year."</a> (".$totals.")</div></p>";
$listheader .= "<ul id=\"".$year."\" style=\"display:none\">";
$completelist .= $listheader.$lister.'</ul>';
	
echo $completelist
?>
<!-- Created by theo van der Sluijs / www.iamboredsoiblog.eu -->
</div>