<?php
/**
* @version		$Id: mod_archiveplus.php
* @copyright	Copyright (C) 2008 Theo van der Sluijs
* @license		http://creativecommons.org/licenses/by-nc-sa/3.0/nl/
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

// Include the syndicate functions only once
require_once (dirname(__FILE__).DS.'helper.php');

$params->def('count', 10);
$list = modArchivePlusHelper::getList($params);

require(JModuleHelper::getLayoutPath('mod_archiveplus'));