=== Verify All ===
Contributors: Theo van der Sluijs
Donate link:https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=9519784
Tags: Google, SEO, Yahoo, Bing, Webmaster Tools, Meta
Requires at least: 2.5
Tested up to: 2.8.5
Stable tag: 1.0

This plugin will allow you to easily verify your WordPress website with Google Webmaster Tools, Yahoo! SiteExplorer and Bing Webmaster Tools

== Description ==

Now you can easily verify your website for Google, Bing and Yahoo!.


== Installation ==

1. Download the plugin, extract and upload it to your plugins folder on your server.

2. Activate the plugin.

3. Go to Settings, and Verify All.

4. Go to Google Webmaster Tools, Yahoo! SiteExplorer and Bing Webmaster Center to get your verification/authentication information.

5. Enter the meta value on the Verify All page and Save Changes.

6. The plugin will generate meta tags on the homepage of your website.


== Changelog ==

= 1.0 =
* Created this great plugin !
