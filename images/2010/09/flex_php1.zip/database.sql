-- 
-- Table structure for table `authors_aut`
-- 

CREATE TABLE `authors_aut` (
  `id_aut` int(11) NOT NULL auto_increment,
  `fname_aut` varchar(255) NOT NULL,
  `lname_aut` varchar(255) default NULL,
  PRIMARY KEY  (`id_aut`),
  UNIQUE KEY `fname_aut` (`fname_aut`,`lname_aut`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `authors_aut`
-- 

INSERT INTO `authors_aut` VALUES (1, 'Dantes', 'Alighierie');
INSERT INTO `authors_aut` VALUES (2, 'William', 'Shakespeare');
INSERT INTO `authors_aut` VALUES (3, 'Umberto', 'Eco');
INSERT INTO `authors_aut` VALUES (4, 'Niccolo', 'Machiavelli');
        