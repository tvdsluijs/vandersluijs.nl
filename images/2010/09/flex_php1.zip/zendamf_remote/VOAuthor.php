<?php
class VOAuthor {
	
	public $id_aut;
	public $fname_aut;
	public $lname_aut;
}
?>